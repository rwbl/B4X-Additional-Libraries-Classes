# To-Do B4X Class xInstrumentationValueIndicator

### UPD: Enhance Documentation
Write up the custom view class documentation, hints and samples.
#### Status
Not started.

### UPD: Review Usage DipToCurrent
Review using DipToCurrent for the Value & Unit DrawText.
#### Status
Not started.

