# Changelog B4X Class xInstrumentationValueIndicator

### v1.00 (Build 20211122)
NEW: First version, published on Anywhere Software B4J Forum B4J Libraries & Classes.
