# Changelog B4X Class xInstrumentationController

### v1.00 (Build 20211119)
NEW: First version, published on Anywhere Software B4J Forum B4J Libraries & Classes.
