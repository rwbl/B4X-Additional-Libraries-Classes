# To-Do B4X Class xInstrumentationController

### UPD: Enhance Documentation
Write up the custom view class documentation, hints and samples.
#### Status
Not started.

### NEW: Property to set the Animated Duration for the Bar
Define a new property to set the duration to display (=redraw) the bar.
Need to explore how.
#### Status
Not started.

### NEW: Property to set the text font
Instead
```
Dim fnt As B4XFont = xui.CreateDefaultFont(mTextSize)
```
set the font
```
#If B4A
Dim fnt As B4XFont = xui.CreateFont(... Need to explore how to set
#End If
#If B4J
Dim fnt As B4XFont = xui.CreateFont(fx.CreateFont("Tahoma", mTextSize, True, False), mTextSize)
#End If
```
#### Status
Not started.

### UPD: Text as Label Views
Instead creating the text ID, Value & Unit with canvas drawtext, consider using labels.
Example for B4J:
```
Dim lblID As Label
lblID.Initialize("")
lblID.TextColor = fx.Colors.Black
lblID.Text = mID
... Set more properties
panelInstrument.AddView(lblID, mBorderWidth, mBase.Height - mBorderWidth - TEXT_BOX_OFFSET, mBase.Width - (mBorderWidth * 2), TEXT_BOX_OFFSET)
```
