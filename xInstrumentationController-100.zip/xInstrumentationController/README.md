[B]xInstrumentationController[/B] is an open source B4X CustomView Class.
The xInstrumentationController purpose is to display a device present value & display and set a setpoint via touch or method.

[B]Features[/B]
[LIST]
[*]Set the device present value (PV) and display on a vertical bar (horizontal is not supported).
[*]Set the device setpoint (SP) (by code or touch) and display as an indicator line, with value (optional), on the vertical bar.
[*]Define two custom events, displayed as small circles (acting as buttons) at the bottom left & right of the instrument.
[*]Many instrument properties can be set either in the visual designer or via methods (code).
[*]Use as indicator (readonly) without ability to set the setpoint and custom events.
[/LIST]
[B]Attached[/B]
The [B]xInstrumentationController-NNN.zip [/B](NNN is version number) archive contains the custom view xInstrumentationController.bas and B4XPages sample project for B4A (tested with v11.0) & B4J (tested with v9.30). The B4i code is not developed.

[B]Install[/B]
Include the custom view file xInstrumentationController.bas in a project either in the project folder or if B4XPages project in the same folder as B4XMainPage.bas (with relative path).

[B]Methods[/B]
See B4XPages sample next or lookup xInstrumentationController.bas.

[B]B4XPages Sample B4XMainPage.bas[/B]
[CODE=b4x]
Sub Class_Globals
	Private Root As B4XView
	Private xui As XUI
	Private xController1 As xInstrumentationController
	Private xController2 As xInstrumentationController
	Private btnSimulator As B4XView
	Private TimerLevel As Timer
End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
	TimerLevel.Initialize("TimerLevel", 2000)
	TimerLevel.Enabled = False
End Sub

Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")
	B4XPages.SetTitle(Me, "B4X CV xInstrumentationController")
	CallSubDelayed(Me, "SetProperties")
End Sub

Private Sub SetProperties
	btnSimulator.Text = IIf(TimerLevel.Enabled, "Stop Simulator", "Start Simulator")
	'Just a few
	xController1.BarBackgroundColor = xui.Color_RGB(220, 220, 220)
	xController1.ScaleMin = 0
	xController1.ScaleMax = 1000
	xController1.ScaleAutoRange = 0
	xController1.Value = Rnd(xController1.ScaleMin, xController1.ScaleMax)
End Sub

Sub TimerLevel_Tick
	xController1.Value = Rnd(xController1.ScaleMin, xController1.ScaleMax)
	Dim ScaleRange As Float = IIf(xController1.ScaleAutoRange == 0, xController1.ScaleMax - xController1.ScaleMin, xController1.ScaleAutoRange)
	xController1.Setpoint = xController1.Value + Rnd(-ScaleRange/2, ScaleRange/2)
	If xController1.Setpoint < 0 Then xController1.Setpoint = 0
	xController2.Value = Rnd(xController2.ScaleMin, xController2.ScaleMax)
End Sub

Private Sub xController1_ValueChanged(value As Float)
	Log($"xController1_ValueChanged: ${LogChange}"$)
End Sub

Private Sub xController1_SetpointChanged(value As Float)
	Log($"xController1_SetpointChanged: ${LogChange}"$)
End Sub

Private Sub LogChange As String
	Return $"Value=${NumberFormat(xController1.value, 0, xController1.ScaleDigits)}"$ & _
	$", Setpoint=${NumberFormat(xController1.setpoint, 0, xController1.ScaleDigits)}"$ & _
	$", Delta=${NumberFormat(xController1.Delta, 0, xController1.ScaleDigits)}"$ & _
	$", Min=${xController1.ScaleMin}, Max=${xController1.ScaleMax}"$
End Sub

Private Sub xController1_CustomAction1
	xui.MsgboxAsync($"Define custom actions or dialogs."$, "Controller1 - Custom Action 1")
End Sub

Private Sub xController1_CustomAction2
	xui.MsgboxAsync($"Define custom actions or dialogs."$, "Controller1 - Custom Action 2")
End Sub

Private Sub xController2_CustomAction2
	xui.MsgboxAsync($"Define custom action or dialogs."$, "Controller2 - Custom Action 2")
End Sub

Private Sub btnSimulator_Click
	TimerLevel.Enabled = Not(TimerLevel.Enabled)
	btnSimulator.Text = IIf(TimerLevel.Enabled, "Stop Simulator", "Start Simulator")
End Sub
[/CODE]

[B]Hints[/B]
The custom view can also be included in a B4X library, like xInstrumentationController.b4xlib.
Create a manifest file manifest.txt:
```
Version=1.00
Supported Platforms=B4A,B4J 
```
Create an ZIP archive: Add manifest.txt, xInstrumentationController.bas.
Save the ZIP archive as xInstrumentationController.b4xlib and copy to the B4J/B4A additional libraries folder.
Note: if using also for B4i, add B4i to the supported platforms - not tested.

[B]Licence[/B]
GNU General Public License v3.0.
Developed for personal use only.

[B]ToDo[/B]
See file TODO.md.

[B]Changelog[/B]
v1.00 (20211119)
See file CHANGELOG.md.
