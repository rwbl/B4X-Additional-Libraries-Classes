# Changelog B4X Class xInstrumentationStateIndicator

### v1.01 (Build 20211115)
NEW: Property Visibility (set instrument visible or hide via code).

### v1.00 (Build 202111DD)
* NEW: First version, published on Anywhere Software B4J Forum B4J Libraries & Classes.
