# Changelog B4X Class xInstrumentationMeter

### v1.1 (Build 20211116)
NEW: Property Bar background color.
NEW: Property Indicator Only - Do not show the bar, but only the indicator (ensure to set large size, i.e. > 30).
NEW: Property Instrument panel background color, border width & color & corner radius.
NEW: Property Scale Font Color used for the scale and the value (if visible).
UPD: Minor changes.

### v1.01 (Build 20211112)
FIX: Minor changes and sample B4i (Thanks to Johan Hormaza).
FIX: Show level horizontal mode; Set font size to bar height.
UPD: If no legend, do not use drawtext.

### v1.00 (Build 20211111)
NEW: First version, published on Anywhere Software B4J Forum B4J Libraries & Classes.
