# To-Do B4X Class xInstrumentationMeter

### UPD: Enhance Documentation
Write up the custom view class documentation, hints and samples.
#### Status
Not started.

### NEW: Property to set the Animated Duration for the Bar
Define a new property to set the duration to display (=redraw) the bar.
Not sure yet how to do that.
#### Status
Not started.
